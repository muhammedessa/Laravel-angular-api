export class Book{
    id!:String;
    name!: String;
    price!: String;
    description!: String;
}